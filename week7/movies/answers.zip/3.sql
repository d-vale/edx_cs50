SELECT
    title
FROM
    movies
WHERE
    YEAR >= 2018
ORDER BY
    title;
