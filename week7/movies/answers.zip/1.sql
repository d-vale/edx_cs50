SELECT
    title
FROM
    movies
WHERE
    YEAR = 2008;
