SELECT
    COUNT(*)
FROM
    ratings
WHERE
    rating = 10.0;
